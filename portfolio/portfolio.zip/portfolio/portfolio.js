$(document).ready(function() {

	$('#new-pfname').click(function() {
		$('.new-pf').hide();
		$('.new-pf-edit').show();
	});

});